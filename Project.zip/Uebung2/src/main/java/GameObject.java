package main.java;

import java.awt.*;

public interface GameObject {
    void update();
    void render(Graphics graphics);
}
