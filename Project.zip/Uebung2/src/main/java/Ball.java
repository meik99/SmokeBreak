package main.java;

public class Ball {

	public void start() {
		// TODO Auto-generated method stub
		
	}

	public void move() {
		// TODO Auto-generated method stub
		
	}

}
