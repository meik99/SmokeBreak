package main.java;

public class Paddle {

	public void move(int x) {
		// TODO Auto-generated method stub
		
	}

	

}
