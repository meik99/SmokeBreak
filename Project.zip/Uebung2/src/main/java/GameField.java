package main.java;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class GameField extends JPanel implements Runnable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final int fieldWidth = 400;
	static final int fieldHeight = 400;
	// number of times the image on the screen is refreshed
	final int FRAME_RATE = 20;
	private  Ball ball;
	private Paddle paddle;
	Image img;
	Graphics g;
	Thread thread;
	
	public void init() {
		ball = new Ball();
		paddle = new Paddle();
		img = createImage(fieldWidth, fieldHeight);
		g = img.getGraphics();
		
		enableEvents(MouseEvent.MOUSE_MOVED | MouseEvent.MOUSE_PRESSED);
	}
	public void start() {
		thread = new Thread(this);
		thread.start();
	}
	public void stop() {
		thread.interrupt();
	}
	// paddle moves as mouse
	public void processMouseMotionEvent(MouseEvent mouse) {
		paddle.move(mouse.getX());
	}
	// ball starts moving if mouse is clicked
	public void processMouseEvent(MouseEvent mouse) {
		if (mouse.getID() == MouseEvent.MOUSE_PRESSED) {
			ball.start();
		}
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			
		
			while(true) {
			ball.move();
			Thread.sleep(1000/FRAME_RATE);
			}
		}
		catch (InterruptedException error) {
			System.out.print("Error ,\n" + error);
		}
		
		
		
	}
	
}
